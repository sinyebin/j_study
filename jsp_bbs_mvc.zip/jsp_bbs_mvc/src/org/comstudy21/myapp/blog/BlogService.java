package org.comstudy21.myapp.blog;

public class BlogService {

}
