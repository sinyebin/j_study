package org.comstudy21.myapp.bbs;

public class BoardService {

}
